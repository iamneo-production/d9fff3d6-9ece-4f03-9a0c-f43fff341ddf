import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { UserLogin } from './user-login';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  loginuser: UserLogin;
 

  constructor( 
      private router: Router, 
        private registationService: RegistrationService,private formbuilder: FormBuilder) {
          this.loginuser = new UserLogin();
  }
  onSubmit(){
    
    this.registationService.LoginUser(this.loginuser).subscribe(data=>{
      if(data===true)
      {
        alert("Customer Suceessfully LoggedIn");
         this.router.navigate(['/']);
      }
      else if(data===false)
      {
        alert("Wrong Username or Password");
          
      }
    });
  
  }
  emailRegex = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
  + "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
passwordRegex ="[A-Za-z\d$@#$^!%?&].{7,15}"; 
LoginForm = this.formbuilder.group({
    email: ['',[Validators.required,Validators.pattern(this.emailRegex)]],
    password:['',[Validators.required,Validators.pattern(this.passwordRegex)]]  
  }); 
  get email(){
    return this.LoginForm.get('email');
  }
  get emailcontrols(){
    return this.LoginForm.controls['email'].errors;
  }
  get password(){
    return this.LoginForm.get('password');
  }
  get passwordcontrols(){
    return this.LoginForm.controls['password'].errors;
  }
 /* gotoLoginList() {
    alert("Suceessfully LoggedIn");
    this.router.navigate(['/']);
  }*/ 
    
  ngOnInit(): void {
  }

}
